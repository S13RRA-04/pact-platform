# PACT OPERATION HARBORLINE · Scenario v0.5

**Development draft for instructor and student scenario delivery. Not agency-approved, not a real warrant or indictment, and not legal advice.**

## Story arc
- Day 1: Four separate investigations (Northbank, Portwell, Kestrel, Seabrook), one case per squad.
- Day 2: KMS remote-access overlap prompts coordination. Late records focus on former contractor Calder Venn, with three separately articulable evidence-location nexuses.
- Day 3: Mock judicial review establishes probable cause and approves three tailored warrants; synchronized searches of Suite 418, Residence R-12 and Storage C-14 produce separately documented evidence returns.
- Day 4: Foreign-provider evidence strengthens but does not resolve all attribution. Northbank's 5.2 GB transfer aligns with legitimate backup; BRKR_AL remains unverified.
- Day 5: Prosecutor-led simulated grand-jury presentation considers narrow Portwell wire-fraud and unauthorized-information-access counts. A strong student may decline other charges pending evidence.

## Folder rules
- `Instructor/` includes full plot, faculty answers, release & source registers. **NEVER distribute this folder to students.**
- `Student/Day1/` and early `Day2/` preserve the v0.4 cases and original continuity facts.
- `Student/Day2/10` is **late Tuesday only**, and introduces person-and-place PC development.
- `Student/Day3/12–14` are **separate simultaneous site returns**; do not distribute before simulated warrant authorization.
- `Student/Day4/15` and `Student/Day5/16–17` replace the former v0.4 Thursday/Friday releases.

## Compatibility and approvals
This is a narrative redesign, not yet a finished approved lesson or assessment. Previous Day3 range-only, Day4 attribution-only, and Day5 director-brief student packets are superseded. Update slides, lesson plans, E05/E06, P04/P05 assessment descriptions and rubric alignment before pilot delivery. Counsel must review statutory element treatment, warrant particulars, grand-jury representation, foreign evidence process, privacy/privilege and presentation procedures. In real federal grand juries the grand jury consists of 16–23 persons; 12 must concur to indict. A smaller faculty classroom panel must use a *simulated educational sufficiency decision*, not a claim to have returned a legally equivalent true bill.

Synthetic reserved IPs (.example domains, etc.) in the original v0.4 materials are not operational endpoints. All named persons, locations, institutions, cases and evidence records are fictional.
